#include <stdio.h>
#include <string.h>
#include <math.h> 
#define NUM 4161
int main()
{
	FILE* wfile;
	int birth[4100], work[4100], p = -1, min = 0x7FFFFFFF, max = 0x80000000;
	char minname[64], maxname[64];
	for (int i = 1; i < NUM; ++i)
	{
		int x = 0, y = 0;
		char dir[32], buf[1024], name[64];
		sprintf(dir, "E:/1/res/%d.txt", i);
		wfile = fopen(dir, "r");
		bool flag = 1;
		while (fgets(buf, 1024, wfile)) {
			if (flag) { strcpy(name, buf); flag = 0; }
			if (strcmp(buf, "�������£�\n") == 0)
			{
				fgets(buf, 1024, wfile);
				if (buf[0] >= 0 && buf[0] <= '9')
				{
					char temp[5];
					memcpy(temp, buf, 4);
					temp[4] = '\0';
					sscanf(temp, "%d", &x);
				}
				else break;
			}
			else if (x != 0 && strcmp(buf, "�뵳ʱ�䣺\n") == 0)
			{
				fgets(buf, 64, wfile);
				if (buf[0] >= 0 && buf[0] <= '9')
				{
					char temp[5];
					memcpy(temp, buf, 4);
					temp[4] = '\0';
					sscanf(temp, "%d", &y);
				}
				else break;
			}
		}
		if (y) {
			birth[++p] = x, work[p] = y;
			if (min > x) {
				strcpy(minname, name);
				min = x;
			}
			if (max < x) {
				strcpy(maxname, name);
				max = x;
			}
		}
		fclose(wfile);
	}
	printf("%s%d��\n%s%d��\n", minname, min, maxname, max);
	double XBA=0,YBA=0;
	for (int i = 0; i <= p; ++i)
		XBA+=birth[i],YBA+=work[i];
	XBA/=p;YBA/=p;
	double fz=0,fm1=0,fm2=0;
	for (int i = 0; i <= p; ++i)
	{
		fz+=(birth[i]-XBA)*(work[i]-YBA);
		fm1+=(birth[i]-XBA)*(birth[i]-XBA);
		fm2+=(work[i]-YBA)*(work[i]-YBA);
	}
	double fm=sqrt(fm1*fm2);
	printf("%lf\n",fz/fm);
	return 0;
}
