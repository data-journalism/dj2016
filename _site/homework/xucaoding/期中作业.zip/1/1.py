from urllib import request
from html.parser import HTMLParser
import os

url = []
homepage = "http://gbzl.people.com.cn/"


class PeopleParser (HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.title = False
        self.info = False
        self.flag = False
        self.exp = False
        self.name = ""
        self.information = []
        self.experience = []
        
    def handle_starttag(self,tag,attrs):
        if tag == 'title':
            self.title = True
        elif tag == 'ul' and attrs:
            for key, value in attrs:
                if key == 'class' and value == 'qk':
                    self.info = True
        elif tag == 'p' and attrs:
            for key, value in attrs:
                if key == 'class' and value == 'jili':
                    self.exp = True
        elif tag == 'li' and self.info == True:
            self.flag = True
            
    def handle_endtag(self,tag):
        if tag == 'title':
            self.title = False
        elif tag == 'ul':
            self.info = False
        elif tag == 'p':
            self.exp = False
        elif tag == 'li':
            self.flag = False

    def handle_data(self,data):
        if self.title == True:
            self.name = data[:data.find(' ')]
        elif self.flag == True:
            self.information.append(data)
        elif self.exp == True:
            self.experience.append(data)

class MYHTMLPARSER (HTMLParser):
    def handle_starttag(self,tag,attrs):
        if tag == 'a':
            for attr in attrs:
               if attr[0] == 'href':
                   url.append(attr[1])

def gethtml(url):
    try:
        page = request.urlopen(url,timeout=10)
        html = page.read()
        return html
    except urllib.URLError:
        return False

def save():
    data = gethtml("http://cpc.people.com.cn/gbzl/flcx.html")
    if data!= False:
            data = data.decode('utf-8')

    with open('html.txt','w') as f:
        for i in data:
            f.writelines(i)

def parser():
    hp = MYHTMLPARSER()
    with open('html.txt','r') as f:
        html = f.readlines()

    for lines in html[164:265]:
        hp.feed(lines)
    hp.close()
    with open('urls.txt','w') as f:
        for i in url:
            f.writelines(i+'\n')
    
def getpeoplehtml():
    with open('urls.txt','r') as f:
        urls = f.readlines()
        if not os.path.exists('people'):
            os.mkdir('people')
        p = 0
        for i in urls:
            temp = homepage+i[:-1]
            print (temp)
            data = gethtml(temp)
            if data != False:
                data = data.decode('utf-8')
                p += 1
                with open('people\\%d.txt' % (p),'w') as f:
                    for d in data:
                        f.writelines(d)

def getinfo():
    if not os.path.exists('res'):
            os.mkdir('res')
    for num in range(1,4161):
        with open('people\\%d.txt' % (num),'r') as f:
            hp = PeopleParser()
            html = f.read()
            hp.feed(html)
            hp.close()
            ff = open('res\\%d.txt'%(num),'w',encoding='gbk')
            try:
                ff.write(hp.name+'\n\n')
                for str in hp.information:
                    ff.write(str.strip()+'\n')
                ff.write('\n')
                for str in hp.experience:
                    ff.writelines(str.strip())
            except UnicodeEncodeError:
                pass
            ff.close()   
            

getinfo()
